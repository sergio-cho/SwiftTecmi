import UIKit

var str = "Hello, playground"
print("I have learned the following")
print("What features make swift a modern and safe language")
print("How to use the swift RELP in Terminal")
print("How to use palygrounds to make writing Sift fun and simple")
/* Parte de la cancion*/
print("Artista:Siddhartha")
print("Verso: Es que lo siento , cada día yo quise decir te quiero ,hubo veces que fue mi temor escucharte ,cuando sabía que algo no estaba bien")

